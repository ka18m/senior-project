﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Senior_Project //TODO: Warning before delete, mass delete, and before changing menus
{
     public partial class Class_Form : Form
     {
          public Class_Form()
          {
               InitializeComponent();
               PopulateDataGridView();
          }

          private void PopulateDataGridView()
          {
               List<Student> all_students = Database_Interface.QueryAllStudents();
               for(int i = 0; i < Program.student_counter; i++)
               {
                    string[] student = all_students.ElementAt(i).ToArray();
                    StudentPanel.Rows.Add(student);
               }
          }

          private void RefreshDataGridView()
          {
               StudentPanel.Rows.Clear();
               PopulateDataGridView();
          }

          private void New_Student_Click(object sender, EventArgs e) //creates Student object, adds to upsert_stack and adds to listbox
          {
               Student new_student = new Student(Convert.ToInt32(cf_id.Text), cf_fname.Text, cf_lname.Text, cf_o_rdglvl.Text.ToCharArray()[0], cf_cur_rdglvl.Text.ToCharArray()[0], cf_goal_rdglvl.Text.ToCharArray()[0]);
               StudentPanel.Rows.Add(new_student.ToArray());
               List <Student> temp =new List<Student>();
               temp.Add(new_student);
               Database_Interface.AddStudents(temp);
               Clear_TextBoxes();
               RefreshDataGridView();
          }

          private void Import_Student_Click(object sender, EventArgs e)
          {
               IO.Import();
          }

          private void Export_One_Click(object sender, EventArgs e)
          {
               List<Student> student = new List<Student>();
               //TODO: figure out how to "select" students 
               IO.StudentsToFile(student);
          }

          private void Export_All_Click(object sender, EventArgs e)
          {
               IO.StudentsToFile(Database_Interface.QueryAllStudents());  //figure out why filename is student name repeated, not separate files
          }

          private void Delete_One_Click(object sender, EventArgs e)  
          {
               Student to_delete = TextboxesToObject();
               Database_Interface.DeleteStudent(to_delete.getID());
               RefreshDataGridView();
          }

          private void Delete_All_Click(object sender, EventArgs e)
          {
               
          }

          private void Home_Click(object sender, EventArgs e)
          {
               Application.Run(new App());
          }

          private Student TextboxesToObject()
          {
               return new Student(Convert.ToInt32(cf_id.Text), cf_fname.Text, cf_lname.Text, cf_o_rdglvl.Text.ToCharArray()[0], cf_cur_rdglvl.Text.ToCharArray()[0], cf_goal_rdglvl.Text.ToCharArray()[0]);
          }

          private void Clear_TextBoxes()
          {
               cf_id.Clear();
               cf_fname.Clear();
               cf_lname.Clear();
               cf_o_rdglvl.Clear();
               cf_cur_rdglvl.Clear();
               cf_goal_rdglvl.Clear();
          }

          private void StudentPanel_CellContentClick(object sender, DataGridViewCellEventArgs e)
          {
               int row = e.RowIndex;
               cf_id.Text = StudentPanel.Rows[row].Cells[0].Value.ToString();
               cf_fname.Text = StudentPanel.Rows[row].Cells[1].Value.ToString();
               cf_lname.Text = StudentPanel.Rows[row].Cells[2].Value.ToString();
               cf_o_rdglvl.Text = StudentPanel.Rows[row].Cells[3].Value.ToString();
               cf_cur_rdglvl.Text = StudentPanel.Rows[row].Cells[4].Value.ToString();
               cf_goal_rdglvl.Text = StudentPanel.Rows[row].Cells[5].Value.ToString();
          }


     }
}
