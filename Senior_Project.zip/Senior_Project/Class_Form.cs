﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Senior_Project 
{
     public partial class Class_Form : Form
     {
          //TODO: "Renumbering" function that adjusts the id numbers of the students. Will need to associate with notes as well. Low-priority
          public Class_Form()
          {
               InitializeComponent();
               Refresh_Data_Grid_View();
          }

          private void Populate_Data_Grid_View()
          {
               //Get list of all students
               List<Student> all_students = Database_Interface.Query_All_Students();

               //Add each student to student panel
               for(int i = 0; i < Program.student_counter; i++)
               {
                    string[] student = all_students.ElementAt(i).ToArray();
                    StudentPanel.Rows.Add(student);
               }
          }

          private void Refresh_Data_Grid_View()
          {
               StudentPanel.Rows.Clear();
               Populate_Data_Grid_View();
          }

          private void New_Student_Click(object sender, EventArgs e)  //https://stackoverflow.com/questions/3036829/how-do-i-create-a-message-box-with-yes-no-choices-and-a-dialogresult
          {
               //Get all values from textbox
               Student new_student = Textboxes_To_Student();

               if(Database_Interface.Query_Student_Exist(new_student.FirstName, new_student.LastName)) //if student already exists...
               {
                    DialogResult dialog = MessageBox.Show("Student already exists. Would you like to update their records?", "Student already exists", MessageBoxButtons.YesNo);
                    if(dialog == DialogResult.Yes)
                    {
                         Database_Interface.Update_Student(new_student);
                    }
                    else if(dialog == DialogResult.No)
                    {
                         return; //close dialog and do nothing
                    }
               }
               else if (cf_id.Text != "")
               {
                    Database_Interface.Update_Student(new_student);
               }
               else 
               {
                    Database_Interface.Add_Student(new_student);
               }
              
               Clear_TextBoxes();
               Refresh_Data_Grid_View();
          }

          private void Import_Student_Click(object sender, EventArgs e)
          {
               IO.Import_One();
               Refresh_Data_Grid_View();
          }

          private void Import_Many_Click(object sender, EventArgs e)
          {
               IO.Import_Many();
               Refresh_Data_Grid_View();
          }

          private void Export_One_Click(object sender, EventArgs e)
          {
               List<Student> student = new List<Student>(); //create temporary list
               
               //Get student obj via textboxes
               Populate_Textboxes();
               Student export = Textboxes_To_Student();
               Clear_TextBoxes();

               student.Add(export); //Add student obj to list (only once since we are exporting one student, but this way we can reuse code)

               IO.Students_To_File(student);
               MessageBox.Show("Exports saved in HomeroomHelper directory");
          }

          private void Export_All_Click(object sender, EventArgs e)
          {
               IO.Students_To_File(Database_Interface.Query_All_Students());
               MessageBox.Show("Exports saved in HomeroomHelper directory");
          }

          private void Delete_One_Click(object sender, EventArgs e)  
          {
               DialogResult result = MessageBox.Show("Are you sure you want to delete this student? (This will also delete all notes associated with the student.)", "Delete Student", MessageBoxButtons.YesNo);
               if(result == DialogResult.Yes)
               {
                    Populate_Textboxes();
                    Student to_delete = Textboxes_To_Student();
                    Database_Interface.Delete_Notes(to_delete.ID);
                    Database_Interface.Delete_Student(to_delete.ID);
                    Clear_TextBoxes();
                    Refresh_Data_Grid_View();
               }
               else { return; }

          }

          private void Delete_All_Click(object sender, EventArgs e)
          {
               DialogResult result = MessageBox.Show("Are you sure you want to delete all students? (This will also delete all notes.)", "Delete Student", MessageBoxButtons.YesNo);
               if (result == DialogResult.Yes)
               {
                    Database_Interface.Delete_All_Students();
                    Clear_TextBoxes();
                    Refresh_Data_Grid_View();
               }
               else { return; }
          }

          private void Home_Click(object sender, EventArgs e)  //home is open in background, just hidden, so close this form and show the other
          {
               this.Close();
          }

          private Student Textboxes_To_Student()
          {
               Student temp = new Student();
               if(cf_id.Text != "")
               {
                    temp.ID = Convert.ToInt32(cf_id.Text);
               }
               temp.FirstName = cf_fname.Text.Trim();
               temp.LastName = cf_lname.Text.Trim();
               temp.StartLevel = Convert.ToChar(cf_o_rdglvl.Text.Trim().ToUpper());
               temp.CurrentLevel = Convert.ToChar(cf_cur_rdglvl.Text.Trim().ToUpper());
               temp.GoalLevel = Convert.ToChar(cf_goal_rdglvl.Text.Trim().ToUpper());

               return temp;
          }

          private void Clear_TextBoxes()
          {
               cf_id.Clear();
               cf_fname.Clear();
               cf_lname.Clear();
               cf_o_rdglvl.Clear();
               cf_cur_rdglvl.Clear();
               cf_goal_rdglvl.Clear();
          }

          private void Populate_Textboxes()
          {
               int row = StudentPanel.CurrentCell.RowIndex;
               if (StudentPanel.Rows[row].Cells[1].Value.ToString() == "")
               {
                    cf_id.Text = StudentPanel.Rows[row].Cells[0].Value.ToString();
                    cf_fname.Text = StudentPanel.Rows[row].Cells[1].Value.ToString();
                    cf_lname.Text = StudentPanel.Rows[row].Cells[2].Value.ToString();
                    cf_o_rdglvl.Text = StudentPanel.Rows[row].Cells[3].Value.ToString();
                    cf_cur_rdglvl.Text = StudentPanel.Rows[row].Cells[4].Value.ToString();
                    cf_goal_rdglvl.Text = StudentPanel.Rows[row].Cells[5].Value.ToString();
               }
          }

          private void Edit_Button_Click(object sender, EventArgs e)
          {
               if (StudentPanel.SelectedRows.Count > 0 && cf_id.Text != "")
               {
                    Database_Interface.Update_Student(Textboxes_To_Student());
               }
               else
               {
                    MessageBox.Show("Please double click a student to edit");
               }

               Clear_TextBoxes();
               Refresh_Data_Grid_View();
          }

          private void StudentPanel_CellContentClick(object sender, DataGridViewCellEventArgs e)
          {
               Populate_Textboxes();
          }

          private void StudentPanel_CellClick(object sender, DataGridViewCellEventArgs e)
          {
               Populate_Textboxes();
          }
     }
}
