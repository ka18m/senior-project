﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Senior_Project
{
    public partial class App : Form
    {
        public App()
        {
            InitializeComponent();
        }

          private void Manage_Classroom_Button_Click(object sender, EventArgs e)
          {
               this.Hide();
               Class_Form cf = new Class_Form();
               cf.ShowDialog();
               this.Show();
          }

          private void Conference_Button_Click(object sender, EventArgs e)
          {
               this.Hide();
               Conference_Form cf = new Conference_Form();
               cf.ShowDialog();
               this.Show();
          }

          private void Help_Reader_Button_Click(object sender, EventArgs e)
          {

          }

          private void Analysis_Class_Button_Click(object sender, EventArgs e)
          {

          }
     }
}
