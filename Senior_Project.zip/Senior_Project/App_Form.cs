﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Senior_Project
{
    public partial class App : Form
    {
        public App()
        {
            InitializeComponent();
        }

          private void manage_classroom_button_Click(object sender, EventArgs e)
          {
               Application.Run(new Class_Form());
          }

          private void conference_button_Click(object sender, EventArgs e)
          {

          }
     }
}
