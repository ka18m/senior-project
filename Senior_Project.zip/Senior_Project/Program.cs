﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Senior_Project
{
    static class Program
    {
          /// <summary>
          /// The main entry point for the application.
          /// </summary>

          public static int student_counter;
          public static int note_counter;

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

               string filename = "startup.txt";
               if (!System.IO.File.Exists(filename))
               {
                    System.IO.File.WriteAllText(filename, "1");
                    System.IO.Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\HomeroomHelper");
                    Database_Interface.Create_DB();
                    student_counter = Database_Interface.Query_Num_Students();
                    note_counter = Database_Interface.Query_Num_Notes();
                    Application.Run(new Welcome_Form());
               }
               else
               {
                    student_counter = Database_Interface.Query_Num_Students();
                    note_counter = Database_Interface.Query_Num_Notes();
                    Application.Run(new App());
               }

          }
    }
}
