﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Senior_Project
{
     static class IO
     {
          public static void Import_Many()
          {
               //Get multiple filepaths
               string[] filepaths;

               OpenFileDialog dialog = new OpenFileDialog();
               dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\HomeroomHelper";
               dialog.Multiselect = true;

               if (dialog.ShowDialog() == DialogResult.OK)
               {
                    filepaths = dialog.FileNames;
                    //For each file, import 1 student
                    foreach (string f in filepaths)
                    {
                         StreamReader reader = new StreamReader(f);
                         Student import_student = String_To_Student(reader.ReadLine());
                         //Add student
                         Database_Interface.Add_Student(import_student);
                    }

               }
               else { MessageBox.Show("Import Multiple failed."); }
          }

          public static void Import_One()
          {
               //Get single file
               string filepath;

               OpenFileDialog dialog = new OpenFileDialog();
               dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\HomeroomHelper";
               dialog.Multiselect = false;

               if(dialog.ShowDialog() == DialogResult.OK)
               {
                    filepath = dialog.FileName;
                    StreamReader reader = new StreamReader(filepath);
                    Student import_student = String_To_Student(reader.ReadLine());

                    //Add student
                    Database_Interface.Add_Student(import_student);
               }
               else { MessageBox.Show("Import failed."); }

          }

          private static Student String_To_Student(string line)
          {
               Student temp = new Student();
               string[] values = line.Split(',');

               temp.FirstName = values[1];
               temp.LastName = values[2];
               temp.StartLevel = Convert.ToChar(values[3]);
               temp.CurrentLevel = Convert.ToChar(values[4]);
               temp.GoalLevel = Convert.ToChar(values[5]);

               return temp;
          }

          private static string Get_File_Date()
          {
               DateTime current_date_and_time = DateTime.Now;
               string month = current_date_and_time.Month.ToString();
               string day = current_date_and_time.Day.ToString();
               string year = current_date_and_time.Year.ToString();
               string hour = current_date_and_time.Hour.ToString();
               string minute = current_date_and_time.Minute.ToString();

               string result = month + "." + day + "." + year + "." + hour + "." + minute;
               return result;
          }

          //from Student array to csv file
          //https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/file-system/how-to-write-to-a-text-file
          public static void Students_To_File (List<Student> students) //TODO: Add notes to the file as lines
          {
               string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\HomeroomHelper\";
               foreach (Student s in students)
               {
                    string filename = path + s.FirstName + s.LastName + Get_File_Date() + ".csv";

                    string line = "";
                    line += s.ID + ",";
                    line += s.FirstName + ",";
                    line += s.LastName + ",";
                    line += s.StartLevel + ",";
                    line += s.CurrentLevel + ",";
                    line += s.GoalLevel;

                    System.IO.File.WriteAllText(filename, line);

               }
          }
     }
}
