﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Senior_Project
{
    class Student
    {
          //Internal data model for students

          //string sql = "CREATE TABLE students (id INT, fname VARCHAR(20), lname VARCHAR(20), startingLvl VARCHAR(1), currentLvl VARCHAR(1), goalLvl VARCHAR(1)";
          int id;
          string fname, lname;
          char startingLvl, currentLvl, goalLvl;

          public Student()
          {
               id = 0;
               fname = "";
               lname = "";
               startingLvl = 'a';
               currentLvl = 'a';
               goalLvl = 'a';
          }

          public Student(int n_id, string n_fname, string n_lname, char n_currentLvl)
          {
               id = n_id;
               fname = n_fname;
               lname = n_lname;
               startingLvl = 'a';
               currentLvl = n_currentLvl;
               goalLvl = 'a';
          }

          public Student(int n_id, string n_fname, string n_lname, char n_startingLvl, char n_currentLvl, char n_goalLvl)
          {
               id = n_id;
               fname = n_fname;
               lname = n_lname;
               startingLvl = n_startingLvl;
               currentLvl = n_currentLvl;
               goalLvl = n_goalLvl;
          }

          public Student(List<string> str_array)
          {
               id = Convert.ToInt32(str_array[0]);
               fname = str_array[1];
               lname = str_array[2];
               startingLvl = Convert.ToChar(str_array[3]);
               currentLvl = Convert.ToChar(str_array[4]);
               goalLvl = Convert.ToChar(str_array[5]);
          }

          public static int Generate_Student_ID()
          {
               Program.student_counter += 1;
               return Program.student_counter;
          }

          public string[] ToArray()
          {
               string[] temp = { ID.ToString(), FirstName, LastName, StartLevel.ToString(), CurrentLevel.ToString(), GoalLevel.ToString() };
               return temp;
          }

          public int ID
          {
               get { return id; }
               set { id = value; }
          }

          public string FirstName
          {
               get { return fname; }
               set { fname = value; }
          }

          public string LastName
          {
               get { return lname; }
               set { lname = value; }
          }
          public char StartLevel
          {
               get { return startingLvl; }
               set { startingLvl = value; }
          }
          public char CurrentLevel
          {
               get { return currentLvl; }
               set { currentLvl = value; }
          }
          public char GoalLevel
          {
               get { return goalLvl; }
               set { goalLvl = value; }
          }
     }
}
